<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "crazymath";
?>